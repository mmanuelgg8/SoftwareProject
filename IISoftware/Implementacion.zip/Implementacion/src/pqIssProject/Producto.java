package pqIssProject;

public class Producto extends Compa�ia{
	protected double precio;
	protected String url;
	protected String ofertas;
	protected double puntuacionMedia;
}
