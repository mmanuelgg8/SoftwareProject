package pqIssProject;

public class Compa�ia {
	protected String nombre;
	private String pais;
}
